<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="light" tilewidth="12" tileheight="10" spacing="1" tilecount="4" columns="3">
 <grid orientation="orthogonal" width="8" height="8"/>
 <image source="../light.png" width="38" height="10"/>
</tileset>
