<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="levels" tilewidth="8" tileheight="8" spacing="1" tilecount="20" columns="20">
 <image source="../levels.png" width="179" height="8"/>
</tileset>
